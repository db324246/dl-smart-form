<template>
  <div class='field-selection'>
    <edu-title title="字段选择"></edu-title>
    <el-collapse v-model="activeNames" accordion>
      <el-collapse-item
        v-for="item in showOriginFields"
        :key="item.key"
        :title="item.title"
        :name="item.key">
        <div :ref="`drag-wrapper_${item.key}`" class="drag-wrapper">
          <div
            class="field-component drag-item"
            :key="'base' + index"
            v-for="(com, index) in item.components">
            <span>{{com.field.label}}</span>
          </div>
          <div class="field-component hide-com"></div>
        </div>
      </el-collapse-item>

      <template v-if="layout !== 'singleField'">
        <el-collapse-item
          v-for="(item, index) in customFields"
          :key="index"
          :title="item.groupName" :name="item.groupName">
          <div
            :ref="`drag-wrapper_${item.groupName}`"
            class="drag-wrapper">
            <div
              v-for="(field, index) in item.fields"
              class="field-component"
              :class="{
                'drag-item': field.type !== 'objectform',
                'complex-com': complexFields.includes(field.type),
                'object-com': field.type === 'objectform',
                'array-com': field.type === 'arrayform',
              }"
              :key="item.groupName + index"
              @click="quoteCustomFields(field)">
              <span>{{field.label}}</span>
            </div>
            <div class="field-component hide-com"></div>
          </div>
        </el-collapse-item>
      </template>
    </el-collapse>

    <!-- 勾选数据子项的字段 -->
    <el-dialog
      :title='dialogTitle'
      :visible.sync='dialogVisible'
      width='580px'
      :close-on-click-modal='false'
      :before-close='handleClose'>
      <template v-if="customField.modelFields.length">
        
        <el-checkbox-group
          v-model="chooseFields"
          value-key="name">
          <el-checkbox
            v-for="field in customField.modelFields"
            :key="field.name"
            :label="field"
            border
            class="field-item"
            :disabled="choosedFieldKeys.includes(field.name)">
            {{field.label}}
          </el-checkbox>
        </el-checkbox-group>
      </template>
      <div v-else class="empty-tip">暂无字段</div>
      <span slot='footer' class='dialog-footer'>
        <el-button @click='handleClose'>取 消</el-button>
        <el-button type='primary' @click='handleSave'>确 定</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
import Bus from '../Bus'
import { deepClone } from '@/utils'
import { basicComponents, advanceComponents, layoutComponents } from './componentsConfig'
export default {
  name: 'field-selection',
  inject: [
    'layout',
    'fieldsArr',
    'customFields',
    'extendedAttrs',
    'generateFieldName'
  ],
  data() {
    return {
      activeNames: '',
      originFieldsConfig: {
        base: {
          key: 'base',
          title: '基础字段',
          components: basicComponents
        },
        high: {
          key: 'high',
          title: '高级字段',
          components: advanceComponents
        },
        layout: {
          key: 'layout',
          title: '布局字段',
          components: layoutComponents
        }
      },
      complexFields: [
        'arrayform',
        'objectform'
      ],
      customField: {
        modelFields: []
      },
      dialogVisible: false,
      draggedObjectFormKeys: [], // 已经拖拽使用过数据子项字段
      choosedFieldKeys: [], // 已经添加到表单的字段
      chooseFields: [] // 本次选择的字段
    }
  },
  computed: {
    showOriginFields() {
      return this.$parent.showOriginFields.map(item => this.originFieldsConfig[item]).filter(item => item)
    },
    dialogTitle() {
      return this.customField && this.customField.label
    },
    chooseFieldKeys() {
      return this.chooseFields.map(field => field.name)
    }
  },
  watch: {
    customFields: {
      handler(val) {
        if (this.layout === 'singleField') return

        this.$nextTick(() => {
          this.customFields.forEach(item => {
            window.Sortable.create(
              this.$refs['drag-wrapper_' + item.groupName][0],
              this.genenrateConfig(
                item.fields.map(field => ({ field }))
              )
            )
          })
        })
      },
      immediate: true
    }
  },
  created() {
    Bus.$on('delete-field', this.handleDelField)

    this.$on('hook:destroyed', () => {
      Bus.$off('delete-field')
    })
  },
  mounted() {
    this.draggInit()
  },
  methods: {
    draggInit() {
      this.showOriginFields.forEach(item => {
        window.Sortable.create(
          this.$refs[`drag-wrapper_${item.key}`][0],
          this.genenrateConfig(item.components)
        )
      })
    },
    // 监听删除字段
    handleDelField({ fieldKey }) {
      const index = this.choosedFieldKeys.indexOf(fieldKey)
      if (index >= 0) {
        this.choosedFieldKeys.splice(index, 1)
      }
    },
    // 引用数据子项的字段
    quoteCustomFields(field) {
      if (field.type !== 'objectform') return
      this.customField = field
      this.chooseFields.push(
        ...this.customField.modelFields
          .filter(f => {
            if (this.choosedFieldKeys.includes(f.name)) return true
            if (this.fieldsArr.some(field => field.name === f.name)) {
              this.choosedFieldKeys.push(f.name)
              return true
            }
            return false
          })
      )
      this.$nextTick(() => {
        this.dialogVisible = true
      })
    },
    // 关闭对话框
    handleClose() {
      this.dialogVisible = false
      this.$nextTick(() => {
        this.chooseFields = []
      })
    },
    // 确定选择
    handleSave() {
      this.chooseFields.forEach(field => {
        if (!this.choosedFieldKeys.includes(field.name)) {
          if (this.layout === 'vertical' && field.type === 'subform') {
            this.$message.warning('重复上报表单中无法引用明细子表字段')
          } else {
            this.choosedFieldKeys.push(field.name)
            Bus.$emit('insert-field', {
              ...field
            })
          }
        }
      })
      this.handleClose()
    },
    // 开始拖拽
    handleDragStart(evt, components) {
      const field = components[evt.oldIndex].field
      this.$store.commit('customForm/setDraggingNode', {
        type: 'field',
        data: {
          name: this.generateFieldName(field.type),
          ...this.$parent.syncFieldInitTo(field),
          ...deepClone(this.extendedAttrs)
        }
      })
    },
    // 结束拖拽
    handleDragEnd() {
      this.$store.commit('customForm/setDraggingNode', null)
    },
    genenrateConfig(components) {
      return {
        sort: false,
        group: {
          name: 'field',
          pull: 'clone',
          put: false
        },
        animation: 200,
        dragClass: 'field-gragged',
        draggable: '.drag-item',
        onStart: event => {
          this.handleDragStart(event, components)
        },
        onEnd: this.handleDragEnd.bind(this)
      }
    }
  }
}
</script>

<style lang='scss' scoped>
.field-selection {
  height: 100%;
  padding-bottom: 50px;
  overflow-y: auto;
}
.edu-title {
  /deep/.edu-title__name {
    font-size: 18px;
    color: $primaryColor;
  }
}
.el-collapse {
  padding: 0 10px;
  border: none;
  .drag-wrapper {
    display: flex;
    flex-wrap: wrap;
    .field-component {
      flex: 1;
      margin-bottom: 20px;
      font-size: 14px;
      font-size: 14px;
      color: #5F5F5F;
      text-align: left;
      span {
        display: inline-block;
        width: 112px;
        height: 36px;
        line-height: 36px;
        text-align: center;
        background: #FFFFFF;
        border: 1px dashed #CBCBCB;
        border-radius: 4px;
        cursor: pointer;
      }
    }
    .complex-com {
      min-width: 100%;
      span {
        width: 100%;
        max-width: 250px;
        padding-left: 15px;
        border-color: $primaryColor;
        color: $primaryColor;
        text-align: left;
      }
    }
    // .array-com span {
    //   position: relative;
    //   &::after {
    //     position: absolute;
    //     content: '';
    //     top: -1px;
    //     right: 0;
    //     width: 36px;
    //     height: 36px;
    //     background: url('~@/components/dlCoustomForm/assets/arrayform.png') no-repeat center;
    //     background-size: 100%;
    //   }
    // }
    .object-com span {
      position: relative;
      &::after {
        position: absolute;
        content: '';
        top: -1px;
        right: 0;
        width: 36px;
        height: 36px;
        background: url('~@/components/dlCoustomForm/assets/objectform.png') no-repeat center;
        background-size: 100%;
      }
    }
    .hide-com {
      min-width: 110px;
      margin-bottom: 0;
    }
  }
}
.custom-fields-button {
  padding: 0 10px;
  margin-bottom: 5px;
}
.field-gragged {
  border: 1px dashed $primaryColor;
  border-radius: 4px;
}
.ghost-row {
  border: 1px solid $primaryColor;
  border-radius: 4px;
}
.el-tag {
  margin-right: 10px;
  margin-bottom: 10px;
  cursor: pointer;
  &.disabled-tag {
    cursor: not-allowed;
  }
}
.empty-tip {
  font-size: 14px;
  color: $infoColor;
  text-align: center;
}
.el-checkbox.is-bordered {
  border-style: dashed;
  margin-right: 0;
  margin-bottom: 10px;
}
.field-item{
  margin-left: 0px !important;
  margin-right: 10px !important;
}
</style>