<template>
  <div class="widget-view "
    v-if="fieldObj && fieldObj.name" 
    :class="{
      'is_req': curFieldAttachedRule.required
    }">

    <!-- 重复上报 -->
    <div class="citeform_box" v-if="fieldObj.type === 'arrayform'">
      <div
        class="citeform_box__title"
        v-if="showLabel">
        {{ fieldObj.label }}
      </div>
      <el-table border>
        <el-table-column
          :label="item.label"
          :key="item.name"
          v-for="item in fieldObj.attrs.tableColumns">
        </el-table-column>
      </el-table>
    </div>

    <!-- 标题/段落 -->
    <div
      v-else-if="fieldObj.type === 'title'"
      class="el-title"
      v-text="fieldObj.value"
      :style="{
        'font-size': fieldObj.attrs.fontSize,
        'font-weight': fieldObj.attrs.fontWeight,
        'color': fieldObj.attrs.color,
        'background-color': fieldObj.attrs.backgroundColor
      }">
    </div>

    <!-- 分割线 -->
    <el-divider v-else-if="fieldObj.type === 'divider'"></el-divider>

    <el-form-item
      :label="showLabel ? fieldObj.label : ''"
      :label-width="showLabel ? labelWidth : '0'"
      v-else>
      <!-- 单行文本 -->
      <template v-if="fieldObj.type === 'input'">
        <el-input
          :style="getMediumWidth"
          v-model="fieldObj.value"
          :placeholder="fieldObj.attrs.placeholder"
        ></el-input>
      </template>

      <!-- 多行文本 -->
      <template v-else-if="fieldObj.type == 'textarea'">
        <el-input type="textarea" :rows="5"
          v-model="fieldObj.value"
          :style="getMediumWidth"
          :placeholder="fieldObj.attrs.placeholder"
        ></el-input>
      </template>

      <!-- 数字输入 -->
      <template v-else-if="fieldObj.type == 'number'">
        <el-input-number 
          v-model="fieldObj.value" 
          :style="getMediumWidth"
        ></el-input-number>
      </template>

      <!-- 单选框组 -->
      <template v-else-if="fieldObj.type == 'radioGroup'">
        <el-radio-group v-model="fieldObj.value"
          :style="getMediumWidth"
        >
          <el-radio  
            :label="item.key" v-for="item in fieldObj.options" :key="item.key"
          >
            {{ item.value }}
          </el-radio>
        </el-radio-group>
      </template>

      <!-- 多选框组 -->
      <template v-else-if="fieldObj.type == 'checkboxGroup'">
        <el-checkbox-group v-model="fieldObj.value"
          :style="getMediumWidth"
        >
          <el-checkbox
            :label="item.key" v-for="item in fieldObj.options" :key="item.key"
          >
            {{ item.value }}
          </el-checkbox>
        </el-checkbox-group>
      </template>

      <!-- 日期选择器 -->
      <template v-else-if="fieldObj.type == 'date'">
        <el-date-picker
          :style="getMediumWidth"
          v-model="fieldObj.value"
          :type="fieldObj.type"
          :format="fieldObj.attrs.format"
          :placeholder="fieldObj.attrs.placeholder"
          :value-format="fieldObj.attrs.format"
        >
        </el-date-picker>
      </template>

      <!-- 日期范围 -->
      <template v-else-if="fieldObj.type == 'dateRange'">
        <el-date-picker
          :style="getMediumWidth"
          v-model="fieldObj.value"
          type="daterange"
          :format="fieldObj.attrs.format"
          :start-placeholder="fieldObj.attrs.startPlaceholder"
          :end-placeholder="fieldObj.attrs.endPlaceholder"
          range-separator="至">
        </el-date-picker>
      </template>

      <!-- 时间选择器 -->
      <template v-else-if="fieldObj.type == 'time'">
        <el-time-picker 
          :style="getMediumWidth"
          v-model="fieldObj.value"
          :placeholder="fieldObj.attrs.placeholder"
          
          :value-format="fieldObj.attrs.format"
        >
        </el-time-picker>
      </template>

      <!-- 时间范围 -->
      <template v-else-if="fieldObj.type == 'timeRange'">
        <el-time-picker 
          :style="getMediumWidth"
          is-range
          v-model="fieldObj.value"
          :start-placeholder="fieldObj.attrs.startPlaceholder"
          :end-placeholder="fieldObj.attrs.endPlaceholder"
          range-separator="至"
        >
        </el-time-picker>
      </template>

      <!-- 颜色选择器 -->
      <!-- <template v-if="fieldObj.type == 'color'">
        <el-color-picker 
          v-model="fieldObj.value"
          
          :show-alpha="fieldObj.attrs.showAlpha"
        ></el-color-picker>
      </template> -->

      <!-- 下拉选择框 -->
      <template v-else-if="fieldObj.type == 'select'">
        <el-select
          :style="getMediumWidth"
          v-model="fieldObj.value"
          :placeholder="fieldObj.attrs.placeholder"
        >
          <el-option v-for="item in fieldObj.options" :key="item.value" :value="item.key" :label="item.value"></el-option>
        </el-select>
      </template>

      <!-- 多选下拉框 -->
      <template v-else-if="fieldObj.type == 'mulSelect'">
        <el-select
          v-model="fieldObj.value"
          :style="getMediumWidth"
          :multiple="true"
          :placeholder="fieldObj.attrs.placeholder"
        >
          <el-option v-for="item in fieldObj.options" :key="item.value" :value="item.key" :label="item.value"></el-option>
        </el-select>
      </template>

      <!-- switch -->
      <template v-else-if="fieldObj.type=='switch'">
        <el-switch
          :style="getMediumWidth"
          v-model="fieldObj.value"
          
        >
        </el-switch>
      </template>

      <!-- 滑块 -->
      <!-- <template v-if="fieldObj.type=='slider'">
        <el-slider 
          v-model="fieldObj.value"
          :min="fieldObj.attrs.min"
          :max="fieldObj.attrs.max"
          
          :step="fieldObj.attrs.step"
          :show-input="fieldObj.attrs.showInput"
          :range="fieldObj.attrs.range"
        ></el-slider>
      </template> -->

      <!-- 文件上传 -->
      <template v-else-if="fieldObj.type=='file'">
        <div v-if="fieldObj.attrs.filetype === 'image'" class="image-uploader">
          <i class="el-icon-plus avatar-uploader-icon"></i>
        </div>
        <el-button v-else size="mini" type="primary" plain icon="el-icon-plus">
            上传图片
        </el-button>
      </template>

      <!-- 级联选择器 -->
      <!-- <template v-if="fieldObj.type == 'cascader'">
        <el-cascader
          v-model="fieldObj.options.value"
          
          :clearable="fieldObj.attrs.clearable"
          :placeholder="fieldObj.attrs.placeholder"
          :options="fieldObj.options.remoteOptions"
        >
        </el-cascader>
      </template> -->

      <!-- 证照上传 -->
      <template v-else-if="fieldObj.type == 'license'">
        <div class="avatar_uploader">
          <img :src="fieldObj.attrs.defaultImg" alt="">
          <div class="avatar_uploader-tips">
            <p>{{fieldObj.attrs.tips}}</p>
            <el-button size='mini' type='primary'>{{fieldObj.attrs.btnText}}</el-button>
          </div>
        </div>
      </template>

      <!-- 选人控件 -->
      <template v-else-if="fieldObj.type == 'personnel'">
        <el-input
          :style="getMediumWidth"
          :placeholder="fieldObj.attrs.placeholder"
        ></el-input>
      </template>
    </el-form-item>

    <field-tag :field="fieldObj"></field-tag>
  </div>
</template>

<script>
import FieldTag from './FieldTag'
export default {
  name: 'widget-item',
  components: { FieldTag },
  inject: ['fieldAttachedRule', 'fieldsArr'],
  props: {
    fieldName: {
      type: String,
      required: true
    },
    fieldData: {
      type: Object,
      default: null
    }
  },
  computed: {
    fieldObj() {
      return this.fieldData || this.fieldsArr.find(f => f.name === this.fieldName)
    },
    curFieldAttachedRule() {
      const json = (this.fieldObj.name && this.fieldAttachedRule[this.fieldObj.name]) || {}
      if (!json.hasOwnProperty('mediumWidth')) {
        this.$set(json, 'mediumWidth', 0)
      }
      return json
    },
    labelWidth() {
      return `${this.curFieldAttachedRule.labelWidth || 100}px`
    },
    showLabel() {
      return this.curFieldAttachedRule.showLabel
    },
    getMediumWidth() {
      if (this.curFieldAttachedRule.mediumWidth > 0) {
        return {
          'width': this.curFieldAttachedRule.mediumWidth + 'px'
        }
      }
    }
  }
}
</script>

<style lang="scss" scoped>
$primary-color: $primaryColor;
$primary-background-color: $tingePrimaryBgColor;

.widget-view{
  position: relative;
  padding-bottom: 10px;
  box-sizing: border-box;
  user-select: none;
  overflow: hidden;
  .el-form-item__content{
    position: unset;
  }

  .widget-view-description{
    height: 15px;
    line-height: 15px;
    font-size:13px;
    margin-top: 6px;
    color:#909399;
  }

  &:after{
    content: '';
    position: absolute;
    left: 0;
    right: 0;
    top: 0;
    bottom: 0;
    display: block;
    z-index: 10;
  }
  .image-uploader {
    width: 135px;
    height: 75px;
    border: 1px dashed #d9d9d9;
    border-radius: 6px;
    display: flex;
    justify-content: center;
    align-items: center;
    .avatar-uploader-icon {
      color: #8c939d;
      font-size: 28px;
    }
  }
  .avatar_uploader {
    display: flex;
    align-items: center;
    img {
      height: 80px;
      width: 80px;
      border-radius: 10px;
    }
    .avatar_uploader-tips {
      margin-left: 30px;
      p {
        color: $infoColor;
        margin: 0;
        font-size: 12px;
        line-height: 20px;
      }
      .el-button {
        margin-top: 10px;
      }
    }
  }
}
.citeform_box {
  .citeform_box__title {
    font-size: 14px;
    padding: 10px 0 10px 20px;
    &::before {
      display: none;
      content: '*';
      color: #f56c6c;
      margin-right: 4px;
    }
  }
}
.widget-view.is_req {
  .citeform_box__title::before {
    display: inline-block;
  }
  /deep/ .el-form-item__label::before {
    content: '*';
    color: #f56c6c;
    margin-right: 4px;
  }
}
.el-divider {
  margin: 10px 0;
}
.el-select {
  /deep/.el-input__suffix-inner {
    pointer-events: none;
  }
}
.el-title {
  padding: 5px 10px;
  user-select: auto;
  background-color: #efdebb;
}
</style>