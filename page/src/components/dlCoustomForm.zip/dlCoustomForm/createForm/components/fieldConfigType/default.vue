<template>
  <div class="default-config">
    请选择字段
  </div>
</template>

<script>
export default {
  name: 'default-config',
  data() {
    return {

    }
  },
  created() {

  },
  methods: {

  }
}
</script>

<style lang='scss' scoped>
.default-config {
  font-size: 14px;
  color: $infoColor;
  text-align: center;
}
</style>