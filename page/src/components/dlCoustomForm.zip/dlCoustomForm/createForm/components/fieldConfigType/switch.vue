<template>
  <el-form class='switch-config' label-position="top" size="small">
    <el-form-item label="字段标题">
      <el-input v-model="form.label" :disabled="disabled"></el-input>
    </el-form-item>
    
    <el-form-item label="默认值">
      <el-switch v-model="form.value" :disabled="disabled"></el-switch>
    </el-form-item>
  </el-form>
</template>

<script>
export default {
  name: 'switch-config',
  props: {
    form: {
      type: Object,
      required: true
    },
    disabled: {
      type: Boolean,
      default: false
    }
  }
}
</script>

<style lang='scss' scoped>
.el-form {
  padding: 0 10px;
  /deep/ .el-form--label-top .el-form-item__label {
    padding: 0;
  }
  .el-form-item {
    margin-bottom: 10px;
  }
}
</style>