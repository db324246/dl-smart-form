import CustomFormCreate from './createForm'
import RowCom from './createForm/layout/FlexTableLayout/RowCom'
import ColCom from './createForm/layout/FlexTableLayout/ColCom'
import CustomFormShow from './showForm'
import CustomFormReport from './reportForm'
import ArrayformField from './reportForm/components/ArrayformField'

// 安装智能表单（创建）
export const createrInstaller = {
  install(Vue) {
    Vue.component(CustomFormCreate.name, CustomFormCreate)
    Vue.component(RowCom.name, RowCom)
    Vue.component(ColCom.name, ColCom)
  }
}

// 安装智能表单（展示）
export const showerInstaller = {
  install(Vue) {
    Vue.component(CustomFormShow.name, CustomFormShow)
  }
}

// 安装智能表单（上报）
export const reporterInstaller = {
  install(Vue) {
    Vue.component(CustomFormReport.name, CustomFormReport)
    Vue.component(ArrayformField.name, ArrayformField)
  }
}

// 全部安装
export default {
  install(Vue) {
    createrInstaller.install(Vue)
    showerInstaller.install(Vue)
    reporterInstaller.install(Vue)
  }
}
